Version = 'v1.2.1'

PixelTypeBS = {

	'background_lny_tex.png': 0,
	'background_lny_tex_.png': 6,
	'background_basic_tex.png': 0,
	'background_basic_tex_.png': 6,
	'background_golden_week_tex.png': 0,
	'background_golden_week_tex_.png': 0,
	'background_retropolis_tex.png': 0,
	'background_mecha_tex.png': 0,
	'characters_tex.png': 0,
	'debug_tex.png': 0,
	'effects_brawler_tex.png': 0,
	'effects_tex.png': 0,
	'events_tex.png': 0,
	'level_tex.png': 0,
	'loading_tex.png': 0,
	'loading_tex_.png': 0,
	'loading_tex__.png': 0,
	'loading_tex___.png': 6,
	'supercell_id_tex.png': 0,
	'ui_tex.png': 0,
	'ui_tex_.png': 0,
	'ui_tex__.png': 0,
	'ui_tex___.png': 0,
	'ui_bgr_tex.png': 0,

}

FileTypeBS = {

	'background_lny_tex.png': 1,
	'background_mecha_tex.png': 1,
	'background_lny_tex_.png': 1,
	'background_basic_tex.png': 1,
	'background_basic_tex_.png': 1,
	'background_golden_week_tex.png': 1,
	'background_golden_week_tex_.png': 1,
	'background_retropolis_tex.png': 1,
	'characters_tex.png': 28,
	'debug_tex.png': 1,
	'effects_brawler_tex.png': 28,
	'effects_tex.png': 28,
	'events_tex.png': 28,
	'level_tex.png': 28,
	'loading_tex.png': 28,
	'loading_tex_.png': 28,
	'loading_tex__.png': 28,
	'loading_tex___.png': 28,
	'supercell_id_tex.png': 1,
	'ui_tex.png': 28,
	'ui_tex_.png': 28,
	'ui_tex__.png': 28,
	'ui_tex___.png': 27,
	'ui_bgr_tex.png': 28,

}
